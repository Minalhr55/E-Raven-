# Web-technology-project
In this project we have created a electronic products review/info website using mern stack.

